import React, { useState, useEffect, useCallback } from 'react';
import { OltSite, PortRecord, OltSiteId } from './types/olt';
import { OLT_SITES } from './data/oltSites';
import {
  getLocalRecords,
  persistPortRecord,
  removePortRecord,
  getSyncStatus,
  subscribeToSiteRecords,
} from './services/firebaseRtdb';
import { BrandedLoadingScreen } from './components/BrandedLoadingScreen';
import { AccessCodeLogin } from './components/AccessCodeLogin';
import { NavigationBar } from './components/NavigationBar';
import { OltDashboard } from './components/OltDashboard';
import { SiteDetailsView } from './components/SiteDetailsView';
import { FirebaseSettingsModal } from './components/FirebaseSettingsModal';

type AppViewState = 'BOOTING' | 'LOCKED' | 'DASHBOARD' | 'SITE_DETAILS';

export default function App() {
  // Check URL parameters for autostart
  const searchParams = new URLSearchParams(window.location.search);
  const autostart = searchParams.get('autostart') === '1';
  const initialSiteParam = searchParams.get('site');

  const [viewState, setViewState] = useState<AppViewState>(() => {
    if (autostart) return 'DASHBOARD';
    return 'BOOTING';
  });

  const [operator, setOperator] = useState<{ name: string; role: string }>({
    name: 'Alex K.',
    role: 'Field Splice Engineer',
  });

  const [selectedSite, setSelectedSite] = useState<OltSite | null>(() => {
    if (initialSiteParam) {
      const match = OLT_SITES.find(
        (s) => s.id === initialSiteParam.toLowerCase() || s.code.toLowerCase() === initialSiteParam.toLowerCase()
      );
      if (match) return match;
    }
    return null;
  });

  const [allRecords, setAllRecords] = useState<PortRecord[]>(() => getLocalRecords());
  const [isFirebaseConnected, setIsFirebaseConnected] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Check sync status on load and intervals
  const refreshSyncStatus = useCallback(() => {
    const status = getSyncStatus();
    setIsFirebaseConnected(status.isFirebaseActive && status.isConnected);
    setAllRecords(getLocalRecords());
  }, []);

  useEffect(() => {
    refreshSyncStatus();
    const interval = setInterval(refreshSyncStatus, 15000);
    return () => clearInterval(interval);
  }, [refreshSyncStatus]);

  // Handle Boot sequence completion
  const handleBootComplete = () => {
    setViewState('LOCKED');
  };

  // Handle Login
  const handleLoginSuccess = (op: { name: string; role: string }) => {
    setOperator(op);
    if (selectedSite) {
      setViewState('SITE_DETAILS');
    } else {
      setViewState('DASHBOARD');
    }
  };

  // Handle Lock / Logout
  const handleLockLogout = () => {
    setViewState('LOCKED');
  };

  // Select Site to view details
  const handleSelectSite = (site: OltSite) => {
    setSelectedSite(site);
    setViewState('SITE_DETAILS');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Navigate back to Dashboard
  const handleNavigateDashboard = () => {
    setSelectedSite(null);
    setViewState('DASHBOARD');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Save Port Record
  const handleSaveRecord = async (record: PortRecord) => {
    await persistPortRecord(record);
    setAllRecords(getLocalRecords());
  };

  // Delete Port Record
  const handleDeleteRecord = async (recordId: string) => {
    if (!selectedSite) return;
    await removePortRecord(selectedSite.id, recordId);
    setAllRecords(getLocalRecords());
  };

  // Filter records for selected site
  const currentSiteRecords = selectedSite
    ? allRecords.filter((r) => r.siteId === selectedSite.id)
    : [];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 antialiased font-sans selection:bg-cyan-500 selection:text-black flex flex-col justify-between">
      {/* 1. Loading Screen */}
      {viewState === 'BOOTING' && (
        <BrandedLoadingScreen onComplete={handleBootComplete} />
      )}

      {/* 2. Access Code Login Screen */}
      {viewState === 'LOCKED' && (
        <AccessCodeLogin
          onLoginSuccess={handleLoginSuccess}
          defaultAccessCode="OLT-2025"
        />
      )}

      {/* 3. Main Authenticated Application Area */}
      {(viewState === 'DASHBOARD' || viewState === 'SITE_DETAILS') && (
        <>
          {/* Top Sticky Navigation */}
          <NavigationBar
            currentSite={selectedSite}
            onNavigateDashboard={handleNavigateDashboard}
            onLockLogout={handleLockLogout}
            onOpenSettings={() => setIsSettingsOpen(true)}
            isFirebaseConnected={isFirebaseConnected}
            operator={operator}
            totalRecordsCount={allRecords.length}
          />

          {/* Main Views */}
          <main className="flex-1 pb-12">
            {viewState === 'DASHBOARD' && (
              <OltDashboard
                sites={OLT_SITES}
                allRecords={allRecords}
                onSelectSite={handleSelectSite}
              />
            )}

            {viewState === 'SITE_DETAILS' && selectedSite && (
              <SiteDetailsView
                site={selectedSite}
                records={currentSiteRecords}
                onNavigateBack={handleNavigateDashboard}
                onSaveRecord={handleSaveRecord}
                onDeleteRecord={handleDeleteRecord}
                operatorName={operator.name}
              />
            )}
          </main>

          {/* Telecom Operational Footer */}
          <footer className="border-t border-slate-900 bg-slate-950/90 py-4 px-6 text-center text-[11px] font-mono text-slate-400">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-slate-300 font-semibold">OLT Core Manager</span>
                <span>•</span>
                <span>17 Regional Hubs (Kisugu, Kitintale, Raxio, Hoima, Mbarara...)</span>
              </div>
              <div className="flex items-center gap-3 text-slate-400">
                <span>ITU-T G.984 / TIA-598-C</span>
                <span>•</span>
                <span className="text-cyan-400 font-mono">
                  {isFirebaseConnected ? 'Firebase RTDB Sync: Active' : 'Local Storage Mode'}
                </span>
              </div>
            </div>
          </footer>
        </>
      )}

      {/* Firebase & Storage Settings Modal */}
      {isSettingsOpen && (
        <FirebaseSettingsModal
          onClose={() => setIsSettingsOpen(false)}
          onConfigChanged={refreshSyncStatus}
        />
      )}
    </div>
  );
}
