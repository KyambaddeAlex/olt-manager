import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getDatabase, ref, set, remove, onValue, Database, off } from 'firebase/database';
import { FirebaseConnectionConfig, OltSiteId, PortRecord, SyncStatus } from '../types/olt';
import { INITIAL_PORT_RECORDS } from '../data/oltSites';

const LOCAL_STORAGE_RECORDS_KEY = 'olt_core_manager_records_v2';
const LOCAL_STORAGE_CONFIG_KEY = 'olt_firebase_rtdb_config_v2';
const LOCAL_STORAGE_PENDING_QUEUE_KEY = 'olt_pending_sync_queue_v2';

let appInstance: FirebaseApp | null = null;
let dbInstance: Database | null = null;
let activeListeners: Record<string, () => void> = {};

/**
 * Retrieves Firebase RTDB connection config from localStorage or environment variables
 */
export function getFirebaseConfig(): FirebaseConnectionConfig {
  try {
    const stored = localStorage.getItem(LOCAL_STORAGE_CONFIG_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.warn('Failed to parse stored Firebase config:', e);
  }

  // Fallback to Vite env variables if provided
  const envUrl = (import.meta as any).env?.VITE_FIREBASE_DATABASE_URL || '';
  const envProjectId = (import.meta as any).env?.VITE_FIREBASE_PROJECT_ID || '';
  const envApiKey = (import.meta as any).env?.VITE_FIREBASE_API_KEY || '';

  return {
    databaseURL: envUrl,
    projectId: envProjectId,
    apiKey: envApiKey,
  };
}

/**
 * Saves and re-initializes Firebase configuration
 */
export function saveFirebaseConfig(config: FirebaseConnectionConfig): boolean {
  try {
    localStorage.setItem(LOCAL_STORAGE_CONFIG_KEY, JSON.stringify(config));
    // Reset existing instances
    cleanupFirebaseListeners();
    appInstance = null;
    dbInstance = null;
    initFirebaseApp();
    return true;
  } catch (e) {
    console.error('Failed to save Firebase config:', e);
    return false;
  }
}

/**
 * Initializes the Firebase Realtime Database application instance
 */
export function initFirebaseApp(): { success: boolean; isConfigured: boolean; error?: string } {
  const config = getFirebaseConfig();

  if (!config.databaseURL || !config.databaseURL.trim().startsWith('https://')) {
    return { success: false, isConfigured: false, error: 'Database URL not configured or invalid' };
  }

  try {
    const existingApps = getApps();
    if (existingApps.length > 0) {
      appInstance = existingApps[0];
    } else {
      appInstance = initializeApp({
        databaseURL: config.databaseURL.trim(),
        projectId: config.projectId?.trim() || 'olt-core-manager',
        apiKey: config.apiKey?.trim() || 'dummy-key',
      });
    }

    dbInstance = getDatabase(appInstance, config.databaseURL.trim());
    return { success: true, isConfigured: true };
  } catch (err: any) {
    console.warn('Firebase init error (operating in local offline mode):', err?.message);
    dbInstance = null;
    return { success: false, isConfigured: true, error: err?.message };
  }
}

/**
 * Reads local cached records from localStorage with fallback to pre-seeded dataset
 */
export function getLocalRecords(): PortRecord[] {
  try {
    const data = localStorage.getItem(LOCAL_STORAGE_RECORDS_KEY);
    if (data) {
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error loading local records:', err);
  }

  // Pre-seed initial records
  saveLocalRecords(INITIAL_PORT_RECORDS);
  return INITIAL_PORT_RECORDS;
}

/**
 * Persists records array into browser local storage
 */
export function saveLocalRecords(records: PortRecord[]): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_RECORDS_KEY, JSON.stringify(records));
  } catch (e) {
    console.error('Failed to persist local records:', e);
  }
}

/**
 * Subscribes to real-time records for a specific OLT site
 * Automatically falls back to local storage and updates when remote RTDB changes
 */
export function subscribeToSiteRecords(
  siteId: OltSiteId,
  onRecordsChanged: (records: PortRecord[]) => void
): () => void {
  // Always immediately emit current local data
  const currentLocal = getLocalRecords();
  const siteLocal = currentLocal.filter((r) => r.siteId === siteId);
  onRecordsChanged(siteLocal);

  if (!dbInstance) {
    const initResult = initFirebaseApp();
    if (!initResult.success) {
      // Local mode only
      const handleStorageUpdate = (e: StorageEvent) => {
        if (e.key === LOCAL_STORAGE_RECORDS_KEY) {
          const updated = getLocalRecords().filter((r) => r.siteId === siteId);
          onRecordsChanged(updated);
        }
      };
      window.addEventListener('storage', handleStorageUpdate);
      return () => window.removeEventListener('storage', handleStorageUpdate);
    }
  }

  if (dbInstance) {
    try {
      const recordsRef = ref(dbInstance, `olt_records/${siteId}`);
      const unsubscribe = onValue(
        recordsRef,
        (snapshot) => {
          if (snapshot.exists()) {
            const val = snapshot.val();
            const remoteList: PortRecord[] = Object.values(val);

            // Merge with local records
            const allLocal = getLocalRecords();
            const otherSites = allLocal.filter((r) => r.siteId !== siteId);
            const merged = [...otherSites, ...remoteList];
            saveLocalRecords(merged);
            onRecordsChanged(remoteList);
          } else {
            // No remote data yet for this site, upload local seed
            if (siteLocal.length > 0) {
              const updates: Record<string, PortRecord> = {};
              siteLocal.forEach((rec) => {
                updates[rec.id] = rec;
              });
              set(recordsRef, updates).catch((err) => console.warn('Sync seed failed:', err));
            }
          }
        },
        (error) => {
          console.warn('Firebase RTDB subscription warning (falling back to local):', error.message);
        }
      );

      activeListeners[siteId] = () => off(recordsRef);
      return () => {
        if (activeListeners[siteId]) {
          activeListeners[siteId]();
          delete activeListeners[siteId];
        }
      };
    } catch (e) {
      console.warn('Subscription error:', e);
    }
  }

  return () => {};
}

/**
 * Saves or updates a port record both locally and in Firebase RTDB
 */
export async function persistPortRecord(record: PortRecord): Promise<{ success: boolean; id: string }> {
  const all = getLocalRecords();
  const existingIdx = all.findIndex((r) => r.id === record.id);

  let updatedList: PortRecord[];
  if (existingIdx >= 0) {
    updatedList = [...all];
    updatedList[existingIdx] = record;
  } else {
    updatedList = [record, ...all];
  }

  saveLocalRecords(updatedList);

  // If Firebase RTDB is active, write to remote node
  if (dbInstance) {
    try {
      const recordRef = ref(dbInstance, `olt_records/${record.siteId}/${record.id}`);
      await set(recordRef, record);
    } catch (err: any) {
      console.warn('Could not sync to Firebase RTDB immediately, queued locally:', err.message);
      queuePendingChange({ type: 'SAVE', record });
    }
  }

  return { success: true, id: record.id };
}

/**
 * Deletes a port record by ID
 */
export async function removePortRecord(siteId: OltSiteId, recordId: string): Promise<boolean> {
  const all = getLocalRecords();
  const filtered = all.filter((r) => r.id !== recordId);
  saveLocalRecords(filtered);

  if (dbInstance) {
    try {
      const recordRef = ref(dbInstance, `olt_records/${siteId}/${recordId}`);
      await remove(recordRef);
    } catch (err: any) {
      console.warn('Could not remove from Firebase RTDB immediately, queued locally:', err.message);
      queuePendingChange({ type: 'DELETE', siteId, recordId });
    }
  }

  return true;
}

/**
 * Resets local database to the default initial seed records
 */
export function resetToSeedData(): void {
  saveLocalRecords(INITIAL_PORT_RECORDS);
}

/**
 * Enqueues failed remote operations for later synchronization
 */
function queuePendingChange(change: any): void {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_PENDING_QUEUE_KEY) || '[]';
    const queue = JSON.parse(raw);
    queue.push({ ...change, timestamp: new Date().toISOString() });
    localStorage.setItem(LOCAL_STORAGE_PENDING_QUEUE_KEY, JSON.stringify(queue));
  } catch (e) {
    console.error('Queue error:', e);
  }
}

/**
 * Gets current sync status
 */
export function getSyncStatus(): SyncStatus {
  const config = getFirebaseConfig();
  const isConfigured = Boolean(config.databaseURL && config.databaseURL.startsWith('https://'));

  let queueCount = 0;
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_PENDING_QUEUE_KEY) || '[]';
    queueCount = JSON.parse(raw).length;
  } catch (e) {}

  return {
    isConnected: Boolean(dbInstance),
    isFirebaseActive: isConfigured && Boolean(dbInstance),
    isSyncing: false,
    pendingQueueCount: queueCount,
    lastSyncTime: new Date().toLocaleTimeString(),
  };
}

/**
 * Cleans up listeners
 */
export function cleanupFirebaseListeners(): void {
  Object.values(activeListeners).forEach((cleanup) => cleanup());
  activeListeners = {};
}
