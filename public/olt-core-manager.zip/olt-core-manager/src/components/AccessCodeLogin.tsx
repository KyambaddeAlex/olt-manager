import React, { useState } from 'react';
import { Lock, KeyRound, ShieldCheck, Eye, EyeOff, Radio, UserCheck, AlertTriangle } from 'lucide-react';

interface AccessCodeLoginProps {
  onLoginSuccess: (operator: { name: string; role: string }) => void;
  defaultAccessCode?: string;
}

export const AccessCodeLogin: React.FC<AccessCodeLoginProps> = ({
  onLoginSuccess,
  defaultAccessCode = 'OLT-2025',
}) => {
  const [accessCode, setAccessCode] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [operatorName, setOperatorName] = useState('Alex K.');
  const [operatorRole, setOperatorRole] = useState('Field Splice Engineer');
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsSubmitting(true);

    const cleanInput = accessCode.trim();

    // Standard demo codes accepted: OLT-2025, 8821, admin, 1234, or default
    const validCodes = [defaultAccessCode.toLowerCase(), '8821', 'admin', '1234', 'telecom'];

    setTimeout(() => {
      if (validCodes.includes(cleanInput.toLowerCase())) {
        onLoginSuccess({
          name: operatorName.trim() || 'Field Operator',
          role: operatorRole,
        });
      } else {
        setErrorMessage(`Invalid access code. Use standard demo code "${defaultAccessCode}" or "8821".`);
        setIsSubmitting(false);
      }
    }, 200);
  };

  const handleDemoBypass = () => {
    setAccessCode(defaultAccessCode);
    setErrorMessage('');
    onLoginSuccess({
      name: operatorName.trim() || 'Field Operator',
      role: operatorRole,
    });
  };

  return (
    <div
      data-testid="login-screen"
      className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-100 p-4 relative overflow-hidden"
    >
      {/* Background radial effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-blue-950/30 via-slate-950 to-slate-950 pointer-events-none" />
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 w-full max-w-md">
        {/* Terminal Card */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-md">
          {/* Header */}
          <div className="flex items-center gap-3 mb-6 pb-5 border-b border-slate-800">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <KeyRound className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white">OLT Core Manager</h1>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  SECURE
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">Optical Line Terminal Operations Console</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Operator Name */}
            <div>
              <label htmlFor="operator-name-input" className="block text-xs font-medium text-slate-300 mb-1.5">
                Operator / Field Technician
              </label>
              <div className="relative">
                <input
                  id="operator-name-input"
                  type="text"
                  value={operatorName}
                  onChange={(e) => setOperatorName(e.target.value)}
                  placeholder="e.g. Alex K. (Splice Eng)"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-lg py-2.5 px-3 text-sm text-slate-100 placeholder:text-slate-400 outline-none transition-colors"
                />
                <UserCheck className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
              </div>
            </div>

            {/* Operator Role */}
            <div>
              <label htmlFor="operator-role-select" className="block text-xs font-medium text-slate-300 mb-1.5">
                Operational Role
              </label>
              <select
                id="operator-role-select"
                value={operatorRole}
                onChange={(e) => setOperatorRole(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-lg py-2.5 px-3 text-sm text-slate-100 outline-none transition-colors"
              >
                <option value="Field Splice Engineer">Field Splice Engineer (Read/Write)</option>
                <option value="NOC Administrator">NOC Operations Administrator (Full Access)</option>
                <option value="Optical Planning Specialist">Optical Planning Specialist (Audit/Design)</option>
                <option value="Quality Assurance Inspector">QA / OTDR Field Inspector</option>
              </select>
            </div>

            {/* Access Code */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="access-code-input" className="block text-xs font-medium text-slate-300">
                  Terminal Access Code
                </label>
                <span className="text-[11px] font-mono text-cyan-400">
                  Demo code: <span className="font-semibold underline cursor-pointer" onClick={() => setAccessCode(defaultAccessCode)}>{defaultAccessCode}</span>
                </span>
              </div>
              <div className="relative">
                <input
                  id="access-code-input"
                  type={showCode ? 'text' : 'password'}
                  value={accessCode}
                  onChange={(e) => {
                    setAccessCode(e.target.value);
                    if (errorMessage) setErrorMessage('');
                  }}
                  placeholder={`Enter code (e.g. ${defaultAccessCode})`}
                  className={`w-full bg-slate-950 border ${
                    errorMessage ? 'border-rose-500' : 'border-slate-800'
                  } focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-lg py-2.5 pl-3 pr-10 text-sm font-mono text-slate-100 placeholder:text-slate-400 outline-none transition-colors`}
                />
                <button
                  type="button"
                  onClick={() => setShowCode(!showCode)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-slate-200 transition-colors"
                  aria-label={showCode ? 'Hide access code' : 'Show access code'}
                >
                  {showCode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div
                role="alert"
                className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2"
              >
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full mt-2 py-2.5 px-4 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-cyan-500/20 active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              <Lock className="w-4 h-4" />
              <span>{isSubmitting ? 'Verifying Terminal Credentials...' : 'Unlock Terminal Console'}</span>
            </button>

            {/* Quick Demo Button */}
            <div className="pt-2 text-center">
              <button
                type="button"
                onClick={handleDemoBypass}
                className="text-xs text-slate-400 hover:text-cyan-400 underline font-mono cursor-pointer transition-colors"
              >
                Quick Demo Login (Use &quot;{defaultAccessCode}&quot;)
              </button>
            </div>
          </form>

          {/* Security Architecture Notice */}
          <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] text-slate-400 leading-relaxed">
            <div className="flex items-center gap-1.5 text-slate-300 font-semibold mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>Telecom Security Protocol</span>
            </div>
            <p>
              Client-side access codes provide local station locking. Production database authorization is managed
              via Firebase Realtime Database security rules and environment variables.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
