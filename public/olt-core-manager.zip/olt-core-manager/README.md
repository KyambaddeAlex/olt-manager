# OLT Core Manager

**OLT Core Manager** is a responsive, professional telecom operations web application designed for managing Optical Line Terminal (OLT) port allocations, 8-board line cards, 16-port PON matrices, fiber-core TIA-598 color codes, GIS distribution node coordinates, and an **Optical Cable Break & Outage Pinpointer (OTDR)** across 17 regional hubs in Uganda.

---

## Key Features

1. **17 Regional OLT Sites**:
   - Pre-configured with central office coordinates, upstream backbone specifications, subrack hardware profiles (Huawei SmartAX MA5800-X7 & ZTE ZXA10 C300), and live port utilization across:
     - Kisugu, Kitintale, Kiruddu, Lubowa, Dundu, Namirembe, Kiwatule, Kimbeja1, Kalinabiri, Nalukolongo, Imperial, Bmk Wampewo, Raxio, Magwa, Hoima, Mbarara, and Kimbeja2.

2. **Chassis & Matrix Management**:
   - Interactive 8-slot subrack visual matrix with 16 SFP+ PON ports per board (128 ports per site, 2,176 network-wide).
   - LED port status indicators (Active, Spare, Fault, Reserved, Empty).
   - Form for board (1–8), port (0–15), core ID, location name, and coordinates with "Use Current Location" GPS action.

3. **Optical Cable Break & Outage Pinpointer (OTDR)**:
   - Calculates optical break distance from time-of-flight: $d = (c \cdot \Delta t) / (2n)$
   - Converts optical meters to physical trench ground distance with adjustable cable helix/slack factors (0% to 12%).
   - Interpolates exact geographic break GPS coordinates along the cable route.
   - Identifies nearest field infrastructure landmarks (manholes, handholes, splice closures).
   - Simulates dual-wavelength OTDR backscatter curves with Fresnel reflection spikes.
   - Provides 1-click Google Maps emergency dispatch route for field crews.
   - Calculates customer circuit impact (subscribers down by split ratio) and step-by-step remediation protocols.

4. **TIA-598-C Fiber-Core Identification**:
   - Automatic 12-color tube and 12-color fiber decoding with visual color swatches.

5. **Data Persistence**:
   - Real-time cloud sync with Firebase Realtime Database (RTDB).
   - Full offline fallback mode using browser local storage with pending queue synchronization.

6. **Labeling & Reporting**:
   - Printable IEC/ITU field patch cord labels with QR code.
   - CSV export for port and core configurations.

---

## Getting Started

### Prerequisites
- [Node.js](https://nodejs.org/) (version 18 or higher recommended)
- `npm` or `yarn` / `bun`

### Installation
1. Extract this zip file into a folder on your computer.
2. Open a terminal in that folder and run:
   ```bash
   npm install
   ```

### Running the App
To start the development server:
```bash
npm run dev
```
Open your browser and navigate to:
```
http://localhost:3000
```

### Access Code / Demo Login
- Default operator access code: `OLT-2025` or `8821`
- Or pass `?autostart=1` in the URL: `http://localhost:3000/?autostart=1`

### Running Unit Tests
All optical formulas, coordinate math, and validation logic can be tested with:
```bash
npx --yes tsx --test src/utils/*.test.ts
```

### Building for Production
```bash
npm run build
```
This generates the optimized production bundle inside the `dist/` directory.

---

## Tech Stack
- **React 19** with TypeScript
- **Vite 6**
- **Tailwind CSS v4**
- **Lucide Icons**
- **Firebase Realtime Database** SDK
